__version__ = "0.8.4.1"

from .readability import Document
